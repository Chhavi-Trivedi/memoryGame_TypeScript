This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.

### Things done

A React TS application that is used to play the memory game with the help of useReducer 

### Screens

![Initial Screen](https://github.com/karthick3018/memoryGame-reactTS/blob/master/src/components/memory/Images/initial.png)
![Mid Screen](https://github.com/karthick3018/memoryGame-reactTS/blob/master/src/components/memory/Images/mid.png)
![Result Screen](https://github.com/karthick3018/memoryGame-reactTS/blob/master/src/components/memory/Images/result.png)
