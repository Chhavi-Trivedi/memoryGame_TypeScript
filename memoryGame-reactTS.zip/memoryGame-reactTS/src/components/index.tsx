import React from 'react';
import Uirender from './memory/uiComponent';

const MemoryGame : React.FC =() => {
  return (
    <>
    <Uirender/>
    </>
  )
}

export default MemoryGame;