import Img1 from './p1.png';
import Img2 from './p2.png';
import Img3 from './p3.png';
import Img4 from './p4.png';
import Img5 from './p5.png';
import Img6 from './p6.png';
import Default from './default.jpg';

export const Images = [
  Img1,
  Img2,
  Img3,
  Img4,
  Img5,
  Img6,
];

export const DefaultImg = Default;