import React from 'react';
import MemoryGame from './components';
import './App.css'

function App() {
  return (
    <>
    <p className='text'>A Memory game for TypeScript programmers </p>
     <MemoryGame/>
    </>
  );
}

export default App;
